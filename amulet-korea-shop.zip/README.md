# AMULET KOREA Shop

Mobile-first online shop connected to Supabase.

## Before deploy
1. Open `config.js`.
2. Add your Supabase Project URL.
3. Add only the browser-safe `anon` / `publishable` key.
4. Never add `service_role` or secret keys.
5. Upload all files to GitHub and import the repository into Vercel.

Pages:
- `index.html` — public shop
- `admin.html` — admin login/product management
