const cfg=window.AMULET_CONFIG;
const db=supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY);
let products=[],categories=[],activeCat=null,cart=JSON.parse(localStorage.getItem("amulet-cart")||"[]");
const $=s=>document.querySelector(s), money=n=>Math.round(Number(n)||0).toLocaleString()+"₮";
function saveCart(){localStorage.setItem("amulet-cart",JSON.stringify(cart));$("#cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0)}
async function load(){
 const [c,p]=await Promise.all([db.from("categories").select("*").order("sort_order"),db.from("products").select("*").eq("is_active",true).order("created_at",{ascending:false})]);
 categories=c.data||[];products=p.data||[];renderCats();renderProducts();saveCart();
}
function renderCats(){$("#categories").innerHTML='<button class="chip active" data-id="">Бүгд</button>'+categories.map(c=>`<button class="chip" data-id="${c.id}">${c.name}</button>`).join("");document.querySelectorAll(".chip").forEach(b=>b.onclick=()=>{activeCat=b.dataset.id||null;document.querySelectorAll(".chip").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderProducts()})}
function renderProducts(){let q=$("#search").value.toLowerCase();let a=products.filter(p=>(!activeCat||String(p.category_id)===String(activeCat))&&p.name.toLowerCase().includes(q));$("#products").innerHTML=a.length?a.map(p=>`<article class="product"><img src="${p.image_url||''}" alt=""><div class="productBody"><h3>${p.name}</h3><div class="krw">₩${Number(p.price_krw).toLocaleString()}</div><div class="price">${money(p.price_mnt)}</div><button class="add" onclick="addCart(${p.id})">Сагсанд хийх</button></div></article>`).join(""):'<p class="muted">Бараа олдсонгүй.</p>'}
window.addCart=id=>{let p=products.find(x=>x.id===id),x=cart.find(x=>x.id===id);x?x.qty++:cart.push({id:p.id,name:p.name,price:Number(p.price_mnt),qty:1});saveCart();openCart()}
function openCart(){renderCart();$("#drawer").classList.remove("hidden")}
function renderCart(){$("#cartItems").innerHTML=cart.length?cart.map((x,i)=>`<div class="cartRow"><div><b>${x.name}</b><br>${money(x.price)} × ${x.qty}</div><button onclick="removeCart(${i})">Устгах</button></div>`).join(""):'<p class="muted">Сагс хоосон.</p>';$("#cartTotal").textContent=money(cart.reduce((a,x)=>a+x.price*x.qty,0))}
window.removeCart=i=>{cart.splice(i,1);saveCart();renderCart()}
$("#search").oninput=renderProducts;$("#cartBtn").onclick=openCart;$("#navCart").onclick=openCart;$("#closeDrawer").onclick=()=>$("#drawer").classList.add("hidden");$("#navCategories").onclick=()=>$("#categories").scrollIntoView({behavior:"smooth"});
$("#orderForm").onsubmit=async e=>{e.preventDefault();if(!cart.length)return $("#orderMsg").textContent="Сагс хоосон байна.";let total=cart.reduce((a,x)=>a+x.price*x.qty,0);let {data:o,error}=await db.from("orders").insert({customer_name:$("#customerName").value,phone:$("#phone").value,address:$("#address").value,total_mnt:total}).select().single();if(error)return $("#orderMsg").textContent="Алдаа: "+error.message;let items=cart.map(x=>({order_id:o.id,product_id:x.id,quantity:x.qty,price_mnt:x.price}));let r=await db.from("order_items").insert(items);if(r.error)return $("#orderMsg").textContent="Алдаа: "+r.error.message;cart=[];saveCart();renderCart();$("#orderMsg").textContent="Захиалга амжилттай илгээгдлээ. №"+o.id;$("#orderForm").reset()}
load();