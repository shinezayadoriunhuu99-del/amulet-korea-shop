const cfg=window.AMULET_CONFIG;
const db=supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY);
const $=s=>document.querySelector(s),money=n=>Math.round(Number(n)||0).toLocaleString()+"₮";
async function state(){let {data:{session}}=await db.auth.getSession();$("#loginBox").classList.toggle("hidden",!!session);$("#adminPanel").classList.toggle("hidden",!session);if(session)loadAdmin()}
$("#loginForm").onsubmit=async e=>{e.preventDefault();let {error}=await db.auth.signInWithPassword({email:$("#email").value,password:$("#password").value});$("#loginMsg").textContent=error?error.message:"Нэвтэрлээ";if(!error)state()}
$("#logoutBtn").onclick=async()=>{await db.auth.signOut();state()}
async function loadAdmin(){
 let [c,p,o]=await Promise.all([db.from("categories").select("*").order("sort_order"),db.from("products").select("*").order("created_at",{ascending:false}),db.from("orders").select("*").order("created_at",{ascending:false})]);
 $("#pCategory").innerHTML=(c.data||[]).map(x=>`<option value="${x.id}">${x.name}</option>`).join("");
 $("#adminProducts").innerHTML=(p.data||[]).map(x=>`<div class="adminItem"><img src="${x.image_url||''}"><b>${x.name}</b><br>₩${Number(x.price_krw).toLocaleString()} / ${money(x.price_mnt)}<br><button class="danger" onclick="delProduct(${x.id})">Устгах</button><div style="clear:both"></div></div>`).join("");
 $("#orders").innerHTML=(o.data||[]).map(x=>`<div class="adminItem"><b>Захиалга #${x.id}</b><br>${x.customer_name} • ${x.phone}<br>${x.address||""}<br><b>${money(x.total_mnt)}</b> • ${x.order_status}</div>`).join("");
}
$("#productForm").onsubmit=async e=>{e.preventDefault();let f=$("#pImage").files[0];if(!f)return;let path=Date.now()+"-"+f.name.replace(/[^a-zA-Z0-9._-]/g,"_");let up=await db.storage.from("product-images").upload(path,f);if(up.error)return $("#productMsg").textContent=up.error.message;let {data:u}=db.storage.from("product-images").getPublicUrl(path);let r=await db.from("products").insert({name:$("#pName").value,description:$("#pDesc").value,category_id:Number($("#pCategory").value),price_krw:Number($("#pKrw").value),exchange_rate:Number($("#pRate").value),stock:Number($("#pStock").value),image_url:u.publicUrl});$("#productMsg").textContent=r.error?r.error.message:"Бараа амжилттай нэмэгдлээ.";if(!r.error){e.target.reset();$("#pRate").value="2.5";loadAdmin()}}
window.delProduct=async id=>{if(confirm("Энэ барааг устгах уу?")){await db.from("products").delete().eq("id",id);loadAdmin()}}
db.auth.onAuthStateChange(()=>state());state();