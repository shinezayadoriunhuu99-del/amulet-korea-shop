// Supabase > Project Settings > API дээрээс эдгээр 2 утгыг оруулна.
// "anon" / "publishable" key нь browser-д ашиглах зориулалттай.
// service_role / secret key-г ЭНД ХЭЗЭЭ Ч БҮҮ ОРУУЛ.
window.AMULET_CONFIG = {
  SUPABASE_URL: "PASTE_YOUR_SUPABASE_URL_HERE",
  SUPABASE_ANON_KEY: "PASTE_YOUR_ANON_OR_PUBLISHABLE_KEY_HERE"
};